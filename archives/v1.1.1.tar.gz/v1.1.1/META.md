# Archive Metadata

| 项目 | 内容 |
|---|---|
| 归档版本 | v1.1.1 |
| 归档时间 | 2026-09-09 18:45 |
| 触发原因 | 源码 v1.1.1 变更，准备更新文档 |

## 变更内容

### 变更模块
- accuracy: `datasets.py` 新增独立数据集管理模块
- configs: `datasets.yaml` 配置变更

### 归档文件清单
```
archives/v1.1.1/
├── META.md
└── docs/
    ├── zh/    # 中文文档快照（34 文件）
    └── en/    # 英文文档快照（34 文件）
```
